import '@testing-library/jest-dom';

// Config global para RTL pode ser adicionado aqui
// Exemplo: mock de window.matchMedia, etc.
